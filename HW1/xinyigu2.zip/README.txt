part1:Use RStudio or Console to run HW1.R, remember to download the dataset
modify the path to that csvfile and the work directory

part2:Use Python3 to run HW1Part2.py, remember to download the data for the Kaggle competition and named as train.csv, test.csv and val.csv 
modify the path to make sure you get the data file(.csv) properly

